// Simplified authentication and data utilities for localStorage storage

// User data types
export interface Reward {
  id: number;
  name: string;
  unlocked: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  referralCode: string;
  donationsRaised: number;
  rewards: Reward[];
}

// Check if user is logged in
export function isLoggedIn(): boolean {
  return localStorage.getItem('currentUser') !== null;
}

// Get current user data
export function getCurrentUser(): User | null {
  const userData = localStorage.getItem('currentUser');
  if (!userData) return null;
  
  try {
    return JSON.parse(userData) as User;
  } catch (e) {
    console.error('Error parsing user data', e);
    return null;
  }
}

// Login user
export function loginUser(email: string, password: string): Promise<User> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // In a real app, we would validate against a backend
      // For demo, we just create a mock user if credentials are provided
      if (email && password) {
        const userData: User = {
          id: "intern123",
          name: "Mohit Chaudhari",
          email: email,
          referralCode: "mohit2025",
          donationsRaised: 1250,
          rewards: [
            { id: 1, name: "Bronze Badge", unlocked: true },
            { id: 2, name: "Silver Badge", unlocked: true },
            { id: 3, name: "Gold Badge", unlocked: false },
            { id: 4, name: "Platinum Badge", unlocked: false },
          ]
        };
        
        localStorage.setItem('currentUser', JSON.stringify(userData));
        resolve(userData);
      } else {
        reject(new Error("Invalid credentials"));
      }
    }, 800);
  });
}

// Register new user
export function registerUser(name: string, email: string, password: string): Promise<User> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (name && email && password) {
        // Generate a referral code based on name
        const referralCode = `${name.toLowerCase().replace(/\s/g, '')}2025`;
        
        const userData: User = {
          id: `intern${Date.now()}`,
          name: name,
          email: email,
          referralCode: referralCode,
          donationsRaised: 0,
          rewards: [
            { id: 1, name: "Bronze Badge", unlocked: false },
            { id: 2, name: "Silver Badge", unlocked: false },
            { id: 3, name: "Gold Badge", unlocked: false },
            { id: 4, name: "Platinum Badge", unlocked: false },
          ]
        };
        
        localStorage.setItem('currentUser', JSON.stringify(userData));
        resolve(userData);
      } else {
        reject(new Error("Please fill in all required fields"));
      }
    }, 800);
  });
}

// Log out user
export function logoutUser(): void {
  localStorage.removeItem('currentUser');
}

// Update user data
export function updateUserData(userData: User): void {
  localStorage.setItem('currentUser', JSON.stringify(userData));
}

// For demo purposes - get dummy leaderboard data
export interface LeaderboardEntry {
  id: string;
  name: string;
  referralCode: string;
  donationsRaised: number;
}

export function getLeaderboardData(): Promise<LeaderboardEntry[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const dummyNames = [
        "Emma Thompson", "Liam Johnson", "Sophia Williams", "Noah Brown", 
        "Olivia Jones", "William Davis", "Ava Miller", "James Wilson",
        "Isabella Moore", "Oliver Taylor", "Mia Anderson", "Lucas Thomas",
        "Charlotte Jackson", "Henry White", "Amelia Harris", "Alexander Martin",
        "Harper Garcia", "Michael Martinez", "Evelyn Robinson", "Daniel Clark"
      ];

      // Create random intern data
      const leaderboardData: LeaderboardEntry[] = dummyNames.map((name, index) => {
        const firstName = name.split(' ')[0].toLowerCase();
        return {
          id: `intern${index+1}`,
          name: name,
          referralCode: `${firstName}2025`,
          donationsRaised: Math.floor(Math.random() * 5000) + 100 // Random donation amount between $100 and $5100
        };
      });

      // Sort by donations (highest first)
      resolve(leaderboardData.sort((a, b) => b.donationsRaised - a.donationsRaised));
    }, 500);
  });
}