import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';

// Define types for our user data
interface Reward {
  id: number;
  name: string;
  unlocked: boolean;
}

interface User {
  id: string;
  name: string;
  email: string;
  referralCode: string;
  donationsRaised: number;
  rewards: Reward[];
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem('currentUser');
    
    if (userData) {
      setUser(JSON.parse(userData));
    } else {
      navigate('/');
    }
    
    setLoading(false);
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    toast.success("Logged out successfully!");
    navigate('/');
  };

  const handleCopyReferralCode = () => {
    if (user) {
      navigator.clipboard.writeText(user.referralCode);
      toast.success("Referral code copied to clipboard!");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4">
        <h1 className="text-2xl font-bold">Please log in to view your dashboard</h1>
        <Button onClick={() => navigate('/')}>Go to Login</Button>
      </div>
    );
  }

  // Calculate the progress for rewards
  const unlockedRewards = user.rewards.filter(reward => reward.unlocked).length;
  const totalRewards = user.rewards.length;
  const rewardProgress = (unlockedRewards / totalRewards) * 100;

  // Calculate donation tiers
  let nextTier = 0;
  if (user.donationsRaised < 500) nextTier = 500;
  else if (user.donationsRaised < 1000) nextTier = 1000;
  else if (user.donationsRaised < 2500) nextTier = 2500;
  else nextTier = 5000;

  const donationProgress = Math.min((user.donationsRaised / nextTier) * 100, 100);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">Intern Portal</h1>
          <div className="space-x-3">
            <Button variant="ghost" onClick={() => navigate('/leaderboard')}>Leaderboard</Button>
            <Button variant="outline" onClick={handleLogout}>Logout</Button>
          </div>
        </div>
      </header>
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {/* User Profile Card */}
          <Card className="md:col-span-1 shadow-lg animate-in fade-in duration-500">
            <CardHeader className="pb-3">
              <CardTitle>Welcome back!</CardTitle>
              <CardDescription>Here's your intern profile</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="h-12 w-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center text-white text-lg font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-xl font-semibold">{user.name}</p>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <p className="text-sm font-medium mb-2">Your Referral Code</p>
                  <div className="flex items-center space-x-2">
                    <code className="relative rounded bg-muted px-[0.5rem] py-[0.4rem] font-mono text-sm font-semibold flex-1">
                      {user.referralCode}
                    </code>
                    <Button variant="outline" size="sm" onClick={handleCopyReferralCode}>
                      Copy
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Donations Card */}
          <Card className="shadow-lg animate-in fade-in duration-500 delay-200">
            <CardHeader>
              <CardTitle>Donations Raised</CardTitle>
              <CardDescription>Your fundraising progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex justify-between items-baseline">
                  <span className="text-3xl font-bold">${user.donationsRaised}</span>
                  <Badge variant={user.donationsRaised >= 1000 ? "default" : "outline"}>
                    {user.donationsRaised >= 1000 ? "Silver Tier" : "Bronze Tier"}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Current</span>
                    <span>Next Tier: ${nextTier}</span>
                  </div>
                  <Progress value={donationProgress} className="h-2" />
                </div>
                
                <div className="bg-muted/50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Donation Tiers:</h4>
                  <ul className="space-y-1 text-sm">
                    <li className="flex justify-between">
                      <span>Bronze</span>
                      <span>$0 - $499</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Silver</span>
                      <span>$500 - $999</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Gold</span>
                      <span>$1,000 - $2,499</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Platinum</span>
                      <span>$2,500+</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Rewards Card */}
          <Card className="shadow-lg animate-in fade-in duration-500 delay-300">
            <CardHeader>
              <CardTitle>Rewards & Unlockables</CardTitle>
              <CardDescription>Track your achievements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-5">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{unlockedRewards} of {totalRewards} unlocked</span>
                  </div>
                  <Progress value={rewardProgress} className="h-2" />
                </div>
                
                <div className="space-y-3">
                  {user.rewards.map(reward => (
                    <div key={reward.id} className="flex items-center gap-3">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center ${reward.unlocked ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'}`}>
                        {reward.unlocked ? (
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                          </svg>
                        ) : (
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="8" x2="12" y2="16"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                          </svg>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className={`font-medium ${reward.unlocked ? 'text-foreground' : 'text-muted-foreground'}`}>{reward.name}</p>
                        <p className="text-xs text-muted-foreground">{reward.unlocked ? 'Unlocked' : 'Locked'}</p>
                      </div>
                      <Badge variant={reward.unlocked ? "default" : "outline"}>
                        {reward.unlocked ? "Earned" : "Locked"}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}