import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';

interface InternData {
  id: string;
  name: string;
  referralCode: string;
  donationsRaised: number;
}

export default function Leaderboard() {
  const navigate = useNavigate();
  const [interns, setInterns] = useState<InternData[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentUser, setCurrentUser] = useState<InternData | null>(null);

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem('currentUser');
    
    if (userData) {
      const user = JSON.parse(userData);
      setCurrentUser({
        id: user.id,
        name: user.name,
        referralCode: user.referralCode,
        donationsRaised: user.donationsRaised
      });
    } else {
      navigate('/');
    }

    // Generate dummy leaderboard data
    const generateLeaderboard = () => {
      const dummyNames = [
        "Emma Thompson", "Liam Johnson", "Sophia Williams", "Noah Brown", 
        "Olivia Jones", "William Davis", "Ava Miller", "James Wilson",
        "Isabella Moore", "Oliver Taylor", "Mia Anderson", "Lucas Thomas",
        "Charlotte Jackson", "Henry White", "Amelia Harris", "Alexander Martin",
        "Harper Garcia", "Michael Martinez", "Evelyn Robinson", "Daniel Clark"
      ];

      // Create random intern data
      const leaderboardData: InternData[] = dummyNames.map((name, index) => {
        const firstName = name.split(' ')[0].toLowerCase();
        return {
          id: `intern${index+1}`,
          name: name,
          referralCode: `${firstName}2025`,
          donationsRaised: Math.floor(Math.random() * 5000) + 100 // Random donation amount between $100 and $5100
        };
      });

      // Sort by donations (highest first)
      return leaderboardData.sort((a, b) => b.donationsRaised - a.donationsRaised);
    };

    // Set leaderboard data
    setInterns(generateLeaderboard());
    setLoading(false);
  }, [navigate]);

  // Filter interns based on search term
  const filteredInterns = interns.filter(intern => 
    intern.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    intern.referralCode.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Get rank of current user
  const getCurrentUserRank = () => {
    if (!currentUser) return null;
    
    const allInterns = [...interns];
    // Add current user if not already in list
    if (!allInterns.some(intern => intern.id === currentUser.id)) {
      allInterns.push(currentUser);
    }
    
    // Sort by donations
    const sortedInterns = allInterns.sort((a, b) => b.donationsRaised - a.donationsRaised);
    
    // Find index of current user
    const userIndex = sortedInterns.findIndex(intern => intern.id === currentUser.id);
    
    return userIndex !== -1 ? userIndex + 1 : null;
  };

  const currentUserRank = getCurrentUserRank();

  // Function to get badge color based on rank
  const getRankBadge = (rank: number) => {
    if (rank === 1) return "bg-amber-500 text-white";
    if (rank === 2) return "bg-gray-300 text-gray-800";
    if (rank === 3) return "bg-amber-700 text-white";
    return "bg-blue-100 text-blue-800";
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">Intern Portal</h1>
          <div className="space-x-3">
            <Button variant="ghost" onClick={() => navigate('/dashboard')}>Dashboard</Button>
            <Button variant="outline" onClick={() => {
              localStorage.removeItem('currentUser');
              navigate('/');
            }}>Logout</Button>
          </div>
        </div>
      </header>
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-3xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Fundraising Leaderboard</h2>
        
        {/* Current User Stats */}
        {currentUser && currentUserRank && (
          <Card className="mb-6 animate-in fade-in duration-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`h-12 w-12 rounded-full flex items-center justify-center text-lg font-bold ${getRankBadge(currentUserRank)}`}>
                    {currentUserRank}
                  </div>
                  <div>
                    <p className="text-xl font-semibold">{currentUser.name} <span className="text-sm font-normal text-muted-foreground">(You)</span></p>
                    <p className="text-sm text-muted-foreground">Code: {currentUser.referralCode}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold">${currentUser.donationsRaised}</p>
                  <p className="text-sm text-muted-foreground">Your Rank: #{currentUserRank}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Search bar */}
        <div className="mb-6">
          <Input
            placeholder="Search by name or referral code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-md"
          />
        </div>
        
        {/* Leaderboard */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Top Fundraisers</CardTitle>
            <CardDescription>Interns ranked by total donations raised</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {filteredInterns.map((intern, index) => (
                <div key={intern.id} className="py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center font-bold ${getRankBadge(index + 1)}`}>
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-medium">{intern.name}</p>
                        <p className="text-xs text-muted-foreground">Code: {intern.referralCode}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xl font-bold">${intern.donationsRaised}</span>
                    </div>
                  </div>
                  {index < filteredInterns.length - 1 && <Separator className="mt-3" />}
                </div>
              ))}

              {filteredInterns.length === 0 && (
                <div className="py-8 text-center">
                  <p className="text-muted-foreground">No results found for "{searchTerm}"</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}